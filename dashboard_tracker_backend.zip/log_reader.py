import os
import re
import time
import json
from datetime import datetime
from db import save_access, inc_metric
import urllib.parse
import subprocess

# Regex melhoradas para capturar apenas o necessário
PATTERN_USER = re.compile(r'uname=([^\s]+)')
PATTERN_UID = re.compile(r'/d/([a-f0-9-]+)(?:/|$)')
PATTERN_NAME = re.compile(r'/d/[a-f0-9-]+/([^\s?]+)')

last_access_time = {}  # Guarda último acesso por usuário+dashboard
DEDUPE_SECONDS = 5  # Segundos para evitar duplicatas

def extract_dashboard_name(log_line):
    """Extrai o nome do dashboard da linha de log"""
    try:
        # Primeiro tenta pegar do path
        match = PATTERN_NAME.search(log_line)
        if match:
            name = urllib.parse.unquote(match.group(1))
            # Remove query strings e parâmetros extras
            name = name.split('?')[0]
            name = name.split(' ')[0]  # Remove tudo depois do espaço
            if name and name != '/':
                return name
    except:
        pass
    
    # Se não encontrar, retorna None (será substituído pelo UID no db.py)
    return None

def extract_dashboard_uid(log_line):
    """Extrai o UID do dashboard"""
    try:
        match = PATTERN_UID.search(log_line)
        if match:
            return match.group(1)
    except:
        return None

def extract_username(log_line):
    """Extrai o nome do usuário"""
    try:
        match = PATTERN_USER.search(log_line)
        if match:
            return match.group(1)
    except:
        return None

def should_process_access(username, dashboard_uid):
    """Verifica se deve processar (evita duplicatas rápidas)"""
    key = f"{username}_{dashboard_uid}"
    now = time.time()
    
    if key in last_access_time:
        if now - last_access_time[key] < DEDUPE_SECONDS:
            return False
    
    last_access_time[key] = now
    return True

def process_log_line(log_line):
    """Processa uma linha de log do Grafana"""
    try:
        if not log_line:
            return
        
        # Verifica se é uma requisição GET para dashboard
        if 'GET' not in log_line or '/d/' not in log_line:
            return
        
        # Extrai informações
        username = extract_username(log_line)
        dashboard_uid = extract_dashboard_uid(log_line)
        
        if not username or not dashboard_uid:
            return
        
        # Verifica duplicata
        if not should_process_access(username, dashboard_uid):
            return
        
        # Extrai nome (pode ser None)
        dashboard_name = extract_dashboard_name(log_line)
        
        timestamp = datetime.utcnow()
        
        print(f"🔥 Dashboard acessado: user={username} uid={dashboard_uid} name={dashboard_name or 'N/A'}")
        
        # Salva no banco
        save_access(username, dashboard_uid, timestamp)
        inc_metric(dashboard_uid, dashboard_name or dashboard_uid)
        
    except Exception as e:
        print(f"🔥 Erro ao processar log: {e}")

def read_logs_via_kubectl():
    """Lê logs do container Grafana via kubectl"""
    print("📡 Monitorando logs do Grafana...")
    
    cmd = [
        "kubectl", "logs",
        "-n", "nm-observ",
        "-l", "app.kubernetes.io/instance=lgtm-deploy",
        "-c", "grafana",
        "-f",
        "--tail=0"
    ]
    
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1
        )
        
        print("✅ Conectado aos logs. Aguardando acessos...")
        
        # Processa stdout
        for line in iter(proc.stdout.readline, ''):
            line = line.strip()
            if line:
                process_log_line(line)
        
        # Monitora stderr
        for err_line in iter(proc.stderr.readline, ''):
            if err_line.strip():
                print(f"⚠️  Erro kubectl: {err_line.strip()}")
                
    except KeyboardInterrupt:
        print("🛑 Monitor interrompido")
    except Exception as e:
        print(f"🔥 ERRO no monitor: {e}")
        import traceback
        traceback.print_exc()

def start_log_monitor():
    """Inicia o monitor de logs"""
    print("🚀 Iniciando captura de logs do Grafana...")
    read_logs_via_kubectl()